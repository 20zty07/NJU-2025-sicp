# ANSWER QUESTION q1

# ANSWER QUESTION q2

# ANSWER QUESTION q3


def factorial(n):
    """Return the factorial of a non-negative integer n.

    >>> factorial(3)
    6
    >>> factorial(5)
    120
    """
    "*** YOUR CODE HERE ***"

    mult=n
    if n==0:
        return 1
    if n==1:
        return 1
    elif n !=1:
        while isinstance(n,int) and n>=2:
                mult=mult*(n-1)
                n=n-1
        return mult
    


def is_right_triangle(a, b, c):
    """Given three integers (maybe non-positive), judge whether the three
    integers can form the three sides of a right triangle.

    >>> is_right_triangle(2, 1, 3)
    False
    >>> is_right_triangle(5, -3, 4)
    False
    >>> is_right_triangle(5, 3, 4)
    True
    """
    "*** YOUR CODE HERE ***"


   
    if a>0 and b>0 and c>0:
        if a**2==b**2+c**2:
            return True
        if b**2==a**2+c**2:
            return True
        if c**2==b**2+a**2:
            return True
        else:
            return False
    else: 
        return False
    
    

def number_of_k(n, k):
    """Return the number of occurrences of k in each digit of a non-negative
    integer n.

    >>> number_of_k(999, 9)
    3
    >>> number_of_k(1234321, 2)
    2
    """
    "*** YOUR CODE HERE ***"

    
    if 0<=k<=9:
        num=0
        if n>=10:
            while n//10>0:
                if n%10==k:
                    num+=1
                    n=n//10
            
                elif n%10!=k:
                    num=num
                    n=n//10
                
            if n//10==0:
                if n==k:
                    num+=1
                else:
                    num=num
            return num
        
        elif 0<=n<=9:
            if n==k:
                num+=1
                return num
            else:
                return num