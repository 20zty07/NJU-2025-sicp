"""Lab 6: OOP and Inheritance"""

import random

# ANSWER QUESTION q1

# ANSWER QUESTION q2

#####################
# Required Problems #
#####################


class PrintModule:
    def pp(self):
        pretty_print(self)


class VendingMachine:
    """A vending machine that vends some product for some price.

    >>> v = VendingMachine('candy', 10)
    >>> v.vend()
    'Machine is out of stock.'
    >>> v.add_funds(15)
    'Machine is out of stock. Here is your $15.'
    >>> v.restock(2)
    'Current candy stock: 2'
    >>> v.vend()
    'You must add $10 more funds.'
    >>> v.add_funds(7)
    'Current balance: $7'
    >>> v.vend()
    'You must add $3 more funds.'
    >>> v.add_funds(5)
    'Current balance: $12'
    >>> v.vend()
    'Here is your candy and $2 change.'
    >>> v.add_funds(10)
    'Current balance: $10'
    >>> v.vend()
    'Here is your candy.'
    >>> v.add_funds(15)
    'Machine is out of stock. Here is your $15.'

    >>> w = VendingMachine('soda', 2)
    >>> w.restock(3)
    'Current soda stock: 3'
    >>> w.restock(3)
    'Current soda stock: 6'
    >>> w.add_funds(2)
    'Current balance: $2'
    >>> w.vend()
    'Here is your soda.'
    """

    def __init__(self, product: str, price: int):
        """Set the product and its price, as well as other instance attributes."""
        "*** YOUR CODE HERE ***"
        self.prod=product
        self.pric=price
        self.curr_fund=0
        self.curr_quan=0
    def restock(self, quantity: int) -> str:
        """Add quantity to the stock and return a message about the updated stock level.

        E.g., Current candy stock: 3
        """
        assert quantity > 0
        self.curr_quan+=quantity
        return f"Current {self.prod} stock: {self.curr_quan}"

    def add_funds(self, funds: int) -> str:
        """If the machine is out of stock, return a message informing the user to restock
        (and return their n dollars).

        E.g., Machine is out of stock. Here is your $4.

        Otherwise, add funds to the balance and return a message about the updated balance.

        E.g., Current balance: $4
        """
        if self.curr_quan<=0:
            return f"Machine is out of stock. Here is your ${funds}."
        self.curr_fund+=funds
        return f"Current balance: ${self.curr_fund}"
    def vend(self) -> str:
        """Dispense the product if there is sufficient stock and funds and
        return a message. Update the stock and balance accordingly.

        E.g., Here is your candy.
        E.g., Here is your candy and $2 change.

        If not, return a message suggesting how to correct the problem.

        E.g., Machine is out of stock.
        E.g., You must add $3 more funds.
        """
        "*** YOUR CODE HERE ***"
        if self.curr_quan<=0:
            return "Machine is out of stock."
        if self.curr_fund<self.pric:
            return f"You must add ${self.pric-self.curr_fund} more funds."
        if self.curr_fund==self.pric:
            self.curr_fund-=self.pric
            self.curr_quan-=1
            return f"Here is your {self.prod}."
        if self.curr_fund>self.pric:
            self.return_fund=self.curr_fund-self.pric
            self.curr_fund=0
            self.curr_quan-=1
            return f"Here is your {self.prod} and ${self.return_fund} change."

class Pet(PrintModule):
    """A pet.

    >>> kyubey = Pet('Kyubey', 'Incubator')
    >>> kyubey.talk()
    Kyubey
    >>> kyubey.eat('Grief Seed')
    Kyubey ate a Grief Seed!
    """

    def __init__(self, name, owner):
        self.is_alive = True  # It's alive!!!
        self.name = name
        self.owner = owner

    def eat(self, thing):
        print(self.name + " ate a " + str(thing) + "!")

    def talk(self):
        print(self.name)

    def to_str(self):
        "*** YOUR CODE HERE ***"
        return'('+self.name+', '+self.owner+')'

class Cat(Pet):
    """A cat.

    >>> vanilla = Cat('Vanilla', 'Minazuki Kashou')
    >>> isinstance(vanilla, Pet) # check if vanilla is an instance of Pet.
    True
    >>> vanilla.talk()
    Vanilla says meow!
    >>> vanilla.eat('fish')
    Vanilla ate a fish!
    >>> vanilla.lose_life()
    >>> vanilla.lives
    8
    >>> vanilla.is_alive
    True
    >>> for i in range(8):
    ...     vanilla.lose_life()
    >>> vanilla.lives
    0
    >>> vanilla.is_alive
    False
    >>> vanilla.lose_life()
    Vanilla has no more lives to lose.
    """

    def __init__(self, name, owner, lives=9):
        "*** YOUR CODE HERE ***"
        self.name=name
        self.owner=owner
        self.lives=lives
        self.is_alive=True
    def talk(self):
        """Print out a cat's greeting."""
        "*** YOUR CODE HERE ***"
        self.greet="meow"
        print(f"{self.name} says {self.greet}!")
    def lose_life(self):
        """Decrements a cat's life by 1. When lives reaches zero, 'is_alive'
        becomes False. If this is called after lives has reached zero, print out
        that the cat has no more lives to lose.
        """
        "*** YOUR CODE HERE ***"
        if self.lives>1:
            self.lives-=1
        elif self.lives==1:
            self.lives-=1
            self.is_alive=False
        elif self.lives==0:
            self.is_alive=False
            print(f"{self.name} has no more lives to lose.")
    def to_str(self):
        "*** YOUR CODE HERE ***"
        return '('+self.name+', '+self.owner+', '+str(self.lives)+')'

class NoisyCat(Cat):  # Does this line need to change?
    """A Cat that repeats things twice.

    >>> chocola = NoisyCat('Chocola', 'Minazuki Kashou')
    >>> isinstance(chocola, Cat) # check if chocola is an instance of Cat.
    True
    >>> chocola.talk()
    Chocola says meow!
    Chocola says meow!
    """
    def talk(self):
        """Talks twice as much as a regular cat."""
        "*** YOUR CODE HERE ***"
        Cat.talk(self)
        Cat.talk(self)

class Colors:
    HEADER = "\033[95m"
    OKBLUE = "\033[34m"
    OKCYAN = "\033[35m"
    WARNING = "\033[93m"
    FAIL = "\033[91m"
    ENDC = "\033[0m"
    BOLD = "\033[1m"
    UNDERLINE = "\033[4m"


def pretty_print(obj):
    """Pretty prints the object using the Colors class.
    >>> kyubey = Pet('Kyubey', 'Incubator')
    >>> pretty_print(kyubey)
    \033[34mPet\033[0m\033[35m(Kyubey, Incubator)\033[0m
    """
    "*** YOUR CODE HERE ***"
    class1=type(obj).__name__
    str1=obj.to_str()
    print(f"{Colors.OKBLUE}"+class1+f"{Colors.ENDC}"+f"{Colors.OKCYAN}"+str1+f"{Colors.ENDC}")