from scheme_eval_apply import *
from scheme_utils import *
from scheme_classes import *
from scheme_builtins import *

#################
# Special Forms #
#################

# Each of the following do_xxx_form functions takes the cdr of a special form as
# its first argument---a Scheme list representing a special form without the
# initial identifying symbol (if, lambda, quote, ...). Its second argument is
# the environment in which the form is to be evaluated.


def do_define_form(expressions, env, tail=True):
    """Evaluate a define form.
    >>> env = create_global_frame()
    >>> do_define_form(read_line("(x 2)"), env) # evaluating (define x 2)
    'x'
    >>> scheme_eval("x", env)
    2
    >>> do_define_form(read_line("(x (+ 2 8))"), env) # evaluating (define x (+ 2 8))
    'x'
    >>> scheme_eval("x", env)
    10
    >>> # problem 10
    >>> env = create_global_frame()
    >>> do_define_form(read_line("((f x) (+ x 2))"), env) # evaluating (define (f x) (+ x 8))
    'f'
    >>> scheme_eval(read_line("(f 3)"), env)
    5
    """
    validate_form(
        expressions, 2
    )  # Checks that expressions is a list of length at least 2
    signature = expressions.first
    if scheme_symbolp(signature):
        # assigning a name to a value e.g. (define x (+ 1 2))
        validate_form(
            expressions, 2, 2
        )  # Checks that expressions is a list of length exactly 2
        # BEGIN PROBLEM 4
        symbol=expressions.first
        value=scheme_eval(expressions.rest.first,env)
        env.define(symbol,value)
        return symbol
        # END PROBLEM 4
    elif isinstance(signature, Pair) and scheme_symbolp(signature.first):
        # defining a named procedure e.g. (define (f x y) (+ x y))
        # BEGIN PROBLEM 10
        formals=signature.rest
        body=expressions.rest
        expr=Pair(formals,body)
        symbol=signature.first
        value=do_lambda_form(expr,env)
        env.define(symbol,value)
        return symbol
        # END PROBLEM 10
    else:
        bad_signature = signature.first if isinstance(signature, Pair) else signature
        raise SchemeError("non-symbol: {0}".format(bad_signature))


def do_quote_form(expressions, env):
    """Evaluate a quote form.

    >>> env = create_global_frame()
    >>> do_quote_form(read_line("((+ x 2))"), env) # evaluating (quote (+ x 2))
    Pair('+', Pair('x', Pair(2, nil)))
    """
    validate_form(expressions, 1, 1)
    # BEGIN PROBLEM 5
    return expressions.first
    # END PROBLEM 5


def do_begin_form(expressions, env, tail=True):
    """Evaluate a begin form.

    >>> env = create_global_frame()
    >>> x = do_begin_form(read_line("((print 2) 3)"), env) # evaluating (begin (print 2) 3)
    2
    >>> x
    3
    """
    validate_form(expressions, 1)
    return eval_all(expressions, env,tail=True)


def do_lambda_form(expressions, env):
    """Evaluate a lambda form.

    >>> env = create_global_frame()
    >>> do_lambda_form(read_line("((x) (+ x 2))"), env) # evaluating (lambda (x) (+ x 2))
    LambdaProcedure(Pair('x', nil), Pair(Pair('+', Pair('x', Pair(2, nil))), nil), <Global Frame>)
    """
    validate_form(expressions, 2)
    formals = expressions.first
    validate_formals(formals)
    # BEGIN PROBLEM 7
    body=expressions.rest
    return LambdaProcedure(formals,body,env)
    # END PROBLEM 7


def do_if_form(expressions, env, tail=True):
    """Evaluate an if form.

    >>> env = create_global_frame()
    >>> do_if_form(read_line("(#t (print 2) (print 3))"), env) # evaluating (if #t (print 2) (print 3))
    2
    >>> do_if_form(read_line("(#f (print 2) (print 3))"), env) # evaluating (if #f (print 2) (print 3))
    3
    """
    validate_form(expressions, 2, 3)
    if is_scheme_true(scheme_eval(expressions.first, env,tail=False)):
        return scheme_eval(expressions.rest.first, env, tail=tail)
    elif len(expressions) == 3:
        return scheme_eval(expressions.rest.rest.first, env,tail=tail)


def do_and_form(expressions, env, tail=True):
    """Evaluate a (short-circuited) and form.

    >>> env = create_global_frame()
    >>> do_and_form(read_line("(#f (print 1))"), env) # evaluating (and #f (print 1))
    False
    >>> # evaluating (and (print 1) (print 2) (print 4) 3 #f)
    >>> do_and_form(read_line("((print 1) (print 2) (print 3) (print 4) 3 #f)"), env)
    1
    2
    3
    4
    False
    """
    # BEGIN PROBLEM 12
    if expressions is nil:
        return True
    while expressions.rest is not nil:
        if is_scheme_false(scheme_eval(expressions.first,env)):
            return False
        expressions=expressions.rest
    return scheme_eval(expressions.first,env,tail=tail)
    # END PROBLEM 12


def do_or_form(expressions, env, tail=True):
    """Evaluate a (short-circuited) or form.

    >>> env = create_global_frame()
    >>> do_or_form(read_line("(10 (print 1))"), env) # evaluating (or 10 (print 1))
    10
    >>> do_or_form(read_line("(#f 2 3 #t #f)"), env) # evaluating (or #f 2 3 #t #f)
    2
    >>> # evaluating (or (begin (print 1) #f) (begin (print 2) #f) 6 (begin (print 3) 7))
    >>> do_or_form(read_line("((begin (print 1) #f) (begin (print 2) #f) 6 (begin (print 3) 7))"), env)
    1
    2
    6
    """
    # BEGIN PROBLEM 12
    if expressions is nil:
        return False
    while expressions is not nil:
        if is_scheme_true(scheme_eval(expressions.first,env=False)):
            return scheme_eval(expressions.first,env,tail=False)
        expressions=expressions.rest
    return False
    # END PROBLEM 12


def do_cond_form(expressions, env, tail=True):
    """Evaluate a cond form.

    >>> do_cond_form(read_line("((#f (print 2)) (#t 3))"), create_global_frame())
    3
    """
    while expressions is not nil:
        clause = expressions.first
        validate_form(clause, 1)
        if clause.first == "else":
            test = True
            if expressions.rest != nil:
                raise SchemeError("else must be last")
        else:
            test = scheme_eval(clause.first, env,tail=False)
        if is_scheme_true(test):
            # BEGIN PROBLEM 13
            if clause.rest is not nil:
                return eval_all(clause.rest,env,tail=tail)
            return test
            # END PROBLEM 13
        expressions = expressions.rest


def do_let_form(expressions, env, tail=True):
    """Evaluate a let form.

    >>> env = create_global_frame()
    >>> do_let_form(read_line("(((x 2) (y 3)) (+ x y))"), env)
    5
    """
    validate_form(expressions, 2)
    let_env = make_let_frame(expressions.first, env,tail)
    return eval_all(expressions.rest, let_env,tail=tail)


def make_let_frame(bindings,env,tail=True):
    """Create a child frame of Frame ENV that contains the definitions given in
    BINDINGS. The Scheme list BINDINGS must have the form of a proper bindings
    list in a let expression: each item must be a list containing a symbol
    and a Scheme expression."""
    if not scheme_listp(bindings):
        raise SchemeError("bad bindings list in let form")
    names = values = nil
    # BEGIN PROBLEM 14
    name1=value1=nil
    bind_copy=bindings
    while bind_copy is not nil:
        bind=bind_copy.first
        validate_form(bind,2,2)
        sym=bind.first
        val=bind.rest.first
        name1=Pair(sym,name1)
        value1=Pair(val,value1)
        bind_copy=bind_copy.rest
    validate_formals(name1)
    while value1 is not nil:
        val=scheme_eval(value1.first,env)
        values=Pair(val,values)
        value1=value1.rest
    while name1 is not nil:
        name=name1.first
        names=Pair(name,names)
        name1=name1.rest
    # END PROBLEM 14
    return env.make_child_frame(names, values)


def do_define_macro(expressions, env):
    """Evaluate a define-macro form.

    >>> env = create_global_frame()
    >>> do_define_macro(read_line("((f x) (car x))"), env)
    'f'
    >>> scheme_eval(read_line("(f (1 2))"), env)
    1
    """
    # BEGIN PROBLEM OPTIONAL_2
    "*** YOUR CODE HERE ***"
    # END PROBLEM OPTIONAL_2


def do_quasiquote_form(expressions, env,tail=True):
    """Evaluate a quasiquote form with parameters EXPRESSIONS in
    Frame ENV."""

    def quasiquote_item(val, env, level):
        """Evaluate Scheme expression VAL that is nested at depth LEVEL in
        a quasiquote form in Frame ENV."""
        if not scheme_pairp(val):
            return val
        if val.first == "unquote":
            level -= 1
            if level == 0:
                expressions = val.rest
                validate_form(expressions, 1, 1)
                return scheme_eval(expressions.first, env)
        elif val.first == "quasiquote":
            level += 1

        return val.map(lambda elem: quasiquote_item(elem, env, level))

    validate_form(expressions, 1, 1)
    return quasiquote_item(expressions.first, env, 1)


def do_unquote(expressions, env):
    raise SchemeError("unquote outside of quasiquote")


#################
# Dynamic Scope #
#################


def do_mu_form(expressions, env):
    """Evaluate a mu form."""
    validate_form(expressions, 2)
    formals = expressions.first
    validate_formals(formals)
    # BEGIN PROBLEM 11
    mu=MuProcedure(formals,expressions.rest)
    
    return mu
    # END PROBLEM 11


SPECIAL_FORMS = {
    "and": do_and_form,
    "begin": do_begin_form,
    "cond": do_cond_form,
    "define": do_define_form,
    "if": do_if_form,
    "lambda": do_lambda_form,
    "let": do_let_form,
    "or": do_or_form,
    "quote": do_quote_form,
    "define-macro": do_define_macro,
    "quasiquote": do_quasiquote_form,
    "unquote": do_unquote,
    "mu": do_mu_form,
}
