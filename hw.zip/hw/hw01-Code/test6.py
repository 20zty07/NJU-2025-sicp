"""t=0
    if n>=10:
        while n//10>=1:
            t=t*10+n%10
            n=n//10
        if n//10==0:
            t=t*10+n
    elif n//10==0:
        t=t*10+n
    
    m=0
    num=1
    if t>=10:
        while t //10>=1:
            if num%2!=0:
                m=m*10+t%10
                num+=1
                t=t//10
            elif num%2==0:
                m=m
                num+=1
                t=t//10
        if t//10==0 and num%2==1:
            m=m*10+t
            return m
        elif t//10==0 and num%2==0:
            return m
    elif 0<=t<10:
        m=t
        return m"""

""" if squ%2==0:
        while squ>=2:
            m=m+(n//10**(squ//2-1))
            squ=squ-2
        return m
    elif squ%2!=0:
        while squ>=1:
            m=m+(n//10**(((squ-1)//2)+1))
            m=m*(10**(((squ-1)//2)+1))
            squ=squ-2

        return m
"""

"""
    if n == 0:
        return 0
    elif n!=0:
        result = 0
        position = 1
        power = 0
        while n > 0:
            digit = n % 10
            if position % 2 == 1:
                result += digit * (10 ** power)
                power += 1
            position += 1
            n //= 10
        return result
"""

def remove_even_position(n):
    """Removes the digits of n in even positions (the 2nd, 4th, 6th, … from left to right),
    and returns the number formed by the remaining digits.

    >>> remove_even_position(0)
    0
    >>> remove_even_position(10)
    1
    >>> remove_even_position(123)
    13
    >>> remove_even_position(123456)
    135
    """
    "*** YOUR CODE HERE ***"
    
    

    squ=1
    if n//10>=1:
        while n//(10**squ)>=1:
            if n//(10**squ)>=1:
                squ+=1
                n=n//10
            elif n//10==0:
                squ=squ  
    elif n//10==0:
        squ=squ  
    #计算这个数字是几位数
    
    

    if squ%2==0 and squ>0:
        while squ>=2:
            m=m+(n%10**(squ//2))
            squ=squ-2
        return m
    elif squ%2!=0 and squ>0:
        while squ>=1:
            m=m+((n//(10**(squ-1)))%10)*(10**(squ-1))
            squ=squ-2

        return m
print(remove_even_position(123))