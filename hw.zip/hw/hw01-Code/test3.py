"""
def remove_even_position(n):

    
    
    t=0
    if n>=10:
        while n//10>=1:
            t=t*10+n%10
            n=n//10
        if n//10==0:
            t=t*10+n
    elif n//10==0:
        t=t*10+n
    
    m=0
    num=1
    if t>=10:
        while t //10>=1:
            if num%2!=0:
                m=m*10+t%10
                num+=1
                t=t//10
            elif num%2==0:
                m=m
                num+=1
                t=t//10
        if t//10==0 and num%2==1:
            m=m*10+t
            return m
        elif t//10==0 and num%2==0:
            return m
    elif 0<=t<10:
        m=t
        return m
print(remove_even_position(100))


"""

def remove_even_position(n):
    squ=1
    if n//10>=1:
        while n//10>=1:
            if n//(10**squ)>=1:
                squ+=1
                n=n//10
        

        
    #计算这个数字是几位数
    m=0
    num=1
    """
    if squ%2==0:
        while squ>=2:
            m=m+(n//10**(squ//2))
            squ=squ-2
        return m
    elif squ%2!=0:
        while squ>=1:
            m=m+(n/(10**((squ+1)//2)))
            squ=squ-2
        return m

print(remove_even_position(5))
"""
    while num <= squ:
        # 计算当前位的权重
        square = 10 ** (squ - num)
        # 提取当前位的数字
        digit = (n // square) % 10

        if num % 2 != 0:  # 如果是奇数位
            m = m * 10 + digit

        num += 1

    return m
print(remove_even_position(5))

