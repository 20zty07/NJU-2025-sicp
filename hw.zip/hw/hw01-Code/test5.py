def remove_even_position(n):
    squ=1
    if n//10>=1:
        while n//10>=1:
            if n//(10**squ)>=1:
                squ+=1
                n=n//10
        

        
    #计算这个数字是几位数
    m=0
    num=1
    
    if squ%2==0:
        while squ>=2:
            m=m+(n//10**(squ//2-1))
            squ=squ-2
        return m
    elif squ%2!=0:
        while squ>=1:
            m=m+(n//(10**((squ-1)//2)))
            squ=squ-2
        return m

print(remove_even_position(1))