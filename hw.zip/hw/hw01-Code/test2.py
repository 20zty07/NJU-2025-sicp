def hailstone(x):
    """Print the hailstone sequence starting at x and return its
    length.

    >>> a = hailstone(10)
    10
    5
    16
    8
    4
    2
    1
    >>> a
    7
    """
    "*** YOUR CODE HERE ***"
    num=0
    while x>1:
        if x%2==0 and x>1:
            print(x)
            x=x//2
        
            num+=1
        elif x%2!=0 and x>1:
            print(x)
            x=3*x+1
        
            num+=1
    if x==1:
        print(x)
        num+=1
    
    return num
    
    

print(hailstone(10))