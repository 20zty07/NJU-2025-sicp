""" Homework 1: Variables & Functions, Control """

from operator import add, sub, mul, neg
from utils import *

def a_add_abs_b(a, b):
    r"""Return `a + abs(b)`, but without calling abs.

    >>> a_add_abs_b(2, 3)
    5
    >>> a_add_abs_b(2, -3)
    5
    >>> # a check to ensure that the return statement remains unchanged!
    >>> import inspect, re
    >>> re.findall(r'^\s*(return .*)', inspect.getsource(a_add_abs_b), re.M)
    ['return h(a, b)']
    """
    if b >= 0:
        h = add
    else:
        h = sub
    return h(a, b)

def two_of_three(x, y, z):
    """Return a*a + b*b, where a and b are the two largest members of the
    positive numbers x, y, and z.

    >>> two_of_three(1, 2, 3)
    13
    >>> two_of_three(5, 3, 1)
    34
    >>> two_of_three(10, 2, 8)
    164
    >>> two_of_three(5, 5, 5)
    50
    >>> check_single_return(two_of_three)
    >>> check_no_square_brackets(two_of_three)
    """
    return max(x*x+y*y,x*x+z*z,y*y+z*z)

def largest_factor(x):
    """Return the largest factor of x that is smaller than x.

    >>> largest_factor(15) # factors are 1, 3, 5
    5
    >>> largest_factor(80) # factors are 1, 2, 4, 5, 8, 10, 16, 20, 40
    40
    >>> largest_factor(13) # factor is 1 since 13 is prime
    1
    """
    "*** YOUR CODE HERE ***"

    y=x-1
    while y>=1:
        if x%y==0:
            return y
        else:
            y=y-1

            


def if_function(condition, true_result, false_result):
    """Return true_result if condition is a true value, and
    false_result otherwise.

    >>> if_function(True, 2, 3)
    2
    >>> if_function(False, 2, 3)
    3
    >>> if_function(3==2, 3+2, 3-2)
    1
    >>> if_function(3>2, 3+2, 3-2)
    5
    """
    if condition :
        return true_result
    else:
        return false_result


def with_if_statement():
    """
    >>> result = with_if_statement()
    2
    >>> print(result)
    None
    """
    if c():
        return t()
    else:
        return f()

def with_if_function():
    """
    >>> result = with_if_function()
    1
    2
    >>> print(result)
    None
    """
    return if_function(c(), t(), f())

def c():
    "*** YOUR CODE HERE ***"
    return 
def t():
    "*** YOUR CODE HERE ***"
    print(1)


def f():
    "*** YOUR CODE HERE ***"
    print(2)
    

def hailstone(x):
    """Print the hailstone sequence starting at x and return its
    length.

    >>> a = hailstone(10)
    10
    5
    16
    8
    4
    2
    1
    >>> a
    7
    """
    "*** YOUR CODE HERE ***"
    num=0
    while x>1:
        if x%2==0 and x>1:
            print(x)
            x=x//2
        
            num+=1
        elif x%2!=0 and x>1:
            print(x)
            x=3*x+1
        
            num+=1
    if x==1:
        print(x)
        num+=1
    return num


def double_factorial(n):
    """Compute the double factorial of n.

    >>> double_factorial(6)  # 6 * 4 * 2
    48
    >>> double_factorial(5)  # 5 * 3 * 1
    15
    >>> double_factorial(3)  # 3 * 1
    3
    >>> double_factorial(1)  # 1
    1
    """
    "*** YOUR CODE HERE ***"
    mul=n
    while n>2:
        mul=mul*(n-2)
        n=n-2
    return mul

def double_ones(n):
    """Return true if n has two ones in a row.

    >>> double_ones(1)
    False
    >>> double_ones(11)
    True
    >>> double_ones(2112)
    True
    >>> double_ones(110011)
    True
    >>> double_ones(12345)
    False
    >>> double_ones(10101010)
    False
    """
    "*** YOUR CODE HERE ***"

    
    while n//10>=1:
        a=n%10
        b=(n//10)%10
        if a==1 and b==1:
            return True
        else:
            n=n//10

    else:
        return False
    
    
def remove_even_position(n):
    """Removes the digits of n in even positions (the 2nd, 4th, 6th, … from left to right),
    and returns the number formed by the remaining digits.

    >>> remove_even_position(0)
    0
    >>> remove_even_position(10)
    1
    >>> remove_even_position(123)
    13
    >>> remove_even_position(123456)
    135
    """
    
    

    squ=1
    if n//10>=1:
        while n//(10**squ)>=1:
            if n//(10**squ)>=1:
                squ+=1
                
            elif n//10==0:
                squ=squ  
    elif n//10==0:
        squ=squ  
    #计算这个数字是几位数
    
    m=0

    if squ%2==0 and squ>0:
        while squ>=2:
            m=m+((n//(10**(squ-1)))%10)*(10**(squ//2-1))
            squ=squ-2
        return m
    elif squ%2!=0 and squ>0:
        while squ>=1:
            m=m+((n//(10**(squ-1)))%10)*(10**((squ-1)//2))
            squ=squ-2

        return m
    


    

def second_largest(x, y, z):
    """Return the second largest value in `x`, `y`, and `z`.

    >>> second_largest(1, 1, 1)
    1
    >>> second_largest(1, 2, 3)
    2
    >>> second_largest(6, 5, 4)
    5
    >>> second_largest(1, 3, 2)
    2
    >>> second_largest(2, 3, 1)
    2
    >>> second_largest('a', 'b', 'c') # characters in python are also comparable
    'b'
    >>> check_no_square_brackets(second_largest)
    """
    "*** YOUR CODE HERE ***"
    if max(x,y,z)==x:
        second=max(y,z)
    elif max(x,y,z)==y:
        second=max(x,z)
    elif max(x,y,z)==z:
        second=max(x,y)
    return second
        

    