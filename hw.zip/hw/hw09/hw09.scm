;;; Homework 09: Macro

; ANSWER QUESTION wwsd

;;; Required Problems

(define (find n lst)
  (define (helper n lst index)
    (if (= (car lst) n)
      index
      (helper n (cdr lst) (+ 1 index))
    )
  )
  (helper n lst 0)
)


(define (find-nest n sym)
  (define (helper flag sym)
    (if (null? (cdr flag))
      (if (= 1 (car flag))
          (list 'car sym)
          (list 'cdr sym) 
      )
      (if (= 1 (car flag))
          (list 'car (helper (cdr flag) sym))
          (list 'cdr (helper (cdr flag) sym))
      )      
    )
  )
  (helper (reverse-lst (record-path n (eval sym))) sym)
  )

(define (reverse-lst lst)
  (define (helper lst result)
    (if (null? lst)
        result
        (helper (cdr lst) (cons (car lst) result))
    )
  )
  (helper lst nil)
)

(define (record-path n lst )
  (if (null? lst)
    #f
    (if (pair? (car lst))
      (cond ((record-path n (car lst)) (cons 1 (record-path n (car lst))))
            ((record-path n (cdr lst)) (cons 2 (record-path n (cdr lst))))
            (else #f)
      )
      (cond ((equal? (car lst) n) (cons 1 nil))
            ((record-path n (cdr lst)) (cons 2 (record-path n (cdr lst))))
            (else #f)
      )
    )
  ) 
)



(define-macro (my/or operands)
  (if(null? operands)
      #f
      (if (null? (cdr operands))
          (car operands)
          `(let ((t ,(car operands)))
            (if t
            t
            (my/or ,(cdr operands)))
          )
      )

  )
)


(define-macro (k-curry fn args vals indices)
  `(lambda ,(eliminate args indices) ,(cons fn (substitute args vals indices)))
)

(define (substitute args vals indices)
  (define (helper args vals indices index)
  (if (null? args)
      nil
      (if (null? indices)
        args
        (if(equal? index (car indices))
           (cons (car vals) (helper (cdr args) (cdr vals) (cdr indices) (+ 1 index)))
           (cons (car args) (helper (cdr args) vals indices (+ 1 index)))
        )
      )
  )
  )
  (helper args vals indices 0)
)
(define (eliminate args indices)
  (define (helper args indices index)
    (if (null? args)
      nil
      (if (null? indices)
        args
        (if(equal? index (car indices))
           (helper (cdr args) (cdr indices) (+ 1 index))
           (cons (car args) (helper (cdr args) indices (+ 1 index)))
        )
  )))
  (helper args indices 0)
)
(define-macro (let* bindings expr)
  (if(null? bindings)
   `(let nil ,expr)
  `(let (,(car bindings)) (let* ,(cdr bindings) ,expr)) )
)

;;; Just For Fun Problems


; Helper Functions for you
(define (cadr lst) (car (cdr lst)))
(define (cddr lst) (cdr (cdr lst)))
(define (caddr lst) (car (cdr (cdr lst))))
(define (cdddr lst) (cdr (cdr (cdr lst))))

(define-macro (infix expr)
  'YOUR-CODE-HERE
)


; only testing if your code could expand to a valid expression 
; resulting in my/and/2 and my/or/2 not hygienic
(define (gen-sym) 'sdaf-123jasf/a123)

; in these two functions you can use gen-sym function.
; assumption:
; 1. scm> (eq? (gen-sym) (gen-sym))
;    #f
; 2. all symbol generate by (gen-sym) will not in the source code before macro expansion
(define-macro (my/and/2 operands)
  'YOUR-CODE-HERE
)

(define-macro (my/or/2 operands)
  'YOUR-CODE-HERE
)
