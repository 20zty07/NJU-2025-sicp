.read hw10_data.sql

-- The size of each dog
CREATE TABLE size_of_dogs AS
  SELECT name, size FROM dogs, sizes WHERE height <=max and height > min ;


-- All dogs with parents ordered by decreasing height of their parent
CREATE TABLE by_parent_height AS
  SELECT child as name from parents as a, dogs as b where b.name=a.parent order by height DESC;
  


-- Sentences about siblings that are the same size
create table helper as
  select a.child ||''||' plus '||b.child as phrase, c.size as same_size from parents as a, parents as b, size_of_dogs as c, size_of_dogs as d
    where a.parent=b.parent and a.child=c.name and b.child=d.name and c.size=d.size
          and a.child < b.child; 
CREATE TABLE sentences AS
  SELECT 'The two siblings, '|| phrase || ' have the same size: '|| same_size from helper;


-- The almighty midterm score of the SICP'25 students
CREATE TABLE midterm_almighty AS
  SELECT max(p1_wwpd)+max(p2_env)+max(p3_lists)+max(p4_functions)+max(p5_abstraction)+max(p6_tests)+max(p7_generators)+max(p8_bonus) from midterm;


-- The total score distribution of SICP'25 midterm exam
create table new_helper as
  select round((floor(total/10))*10,1) as new_score from midterm;
CREATE TABLE midterm_distribution AS
  SELECT new_score,count(new_score) from new_helper 
        group by new_score order by new_score desc;
